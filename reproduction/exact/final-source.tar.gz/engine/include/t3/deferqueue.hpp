// A busy recipient's waiting messages, smallest (sender << 32 | message id) first.
//
// ABIDES requeues a message for a busy agent at the time the agent is free, and messages due at
// the same time leave in (sender, id) order; this queue holds one recipient's requeued messages
// in that order.
//
// Who waits here, counted on scaled public units (2026-10-10 and 2026-10-11): market makers
// taking the exchange's acknowledgements, one sender, ids ascending, arriving a little out of
// order through the latency jitter. Half of all deliveries of a deep book pass through this
// queue. It is 5 entries long on average at 8 quote levels, 50 at 32, 184 at 100 and 483 at
// 250, and a new entry belongs 3, 16, 50 and 124 places from the back.
//
// It was a binary heap (two walks of log2(n) unpredictable steps per message), then a sorted
// array with a moving front: the smallest entry leaves by advancing an index, and a new one is
// put in place by moving the entries that follow it. That is what a short or a sparse queue
// still is. But at 100 levels finding the place and moving 50 entries was a fifth of the event
// loop (perf, C4 VM, 2026-10-11). So where the entries are close together they are filed by
// their value instead: one bit each in a window of kWindow consecutive values, set on the way
// in, the lowest set bit found on the way out, and nothing is moved. A maker's acknowledgements
// are close: its own with a few other messages' ids in between, 145 ids from first to last on
// average at 32 levels (50 waiting), 538 at 100 and 1,463 at 250 (2,976 at most).
//
// The queue is one or the other. It starts as the array; a push that finds kMin entries or more
// spanning at most kGap values each moves them all into the window (it looks when their number
// is a power of two, so a queue that stays in the array pays one test for it), and there the
// queue stays until it has run empty. Not a little of both: with forty makers at the same
// prices each has five acknowledgements waiting, 70 ids apart, and with some in the window and
// some in the array every look at the front was a coin toss between the two (-7% on that run,
// desktop, 2026-10-11). Only what the window cannot hold while it is in use goes to the array
// then: a value kWindow or more from its entries, which is another sender's message (here the
// recipient's own wake-up, four billion above) or an id far ahead. The smaller front of the
// two leaves first.
//
// Event loop time against the sorted array alone (C4 VM, 2026-10-11, the loop on its own core,
// 5 rounds, GCC and the Intel build alike): +14% at 24 quote levels, +15 to +18% at 32, +21 to
// +23% at 60, +27% at 100, +29% at 150 and +32 to +33% at 250; +6 to +7% at 10 levels, +3 to +5%
// with five makers at 12; +2 to +4% at the 8 levels of the public deep-book unit.
//
// With 12 and with 40 makers at the same prices it was 3 to 6% slower. A maker's
// acknowledgements are then a maker count apart, its queue hovers around kMin entries, and the
// test that looks at it is a branch the processor cannot predict (0.3 more mispredictions per
// delivery, perf). The kernel knows the maker count before the run: use_window(false) keeps a
// queue the array it was (sim_kernel.inc: runs with more than eight market makers).
#pragma once

#include <algorithm>
#include <bit>
#include <cstddef>
#include <cstdint>
#include <memory>
#include <vector>

namespace t3 {

class alignas(64) DeferQueue {
   public:
    static constexpr uint64_t kWindow = 16384;  // values the window spans (a power of two): 2 KiB of bits
    static constexpr size_t kMin = 4;           // entries in the array from which the window is considered
    static constexpr uint64_t kGap = 16;        // and taken into use if they span no more values each








    // The array's storage, for the kernel's reserve-and-fault-in helper; holds no entries yet.
    std::vector<uint64_t>& storage() { return v_; }
    // Whether this queue may move to the window when it grows long (it may unless told not to).
    // Call it on an empty queue.
    void use_window(bool yes) { windows_ = yes; }

    // `sid` is not in the queue.
    void push(uint64_t sid) {
        if (n_win_ != 0) {  // the window is in use: it takes whatever is within its width
            const uint64_t lo = lo_ < sid ? lo_ : sid, hi = hi_ > sid ? hi_ : sid;
            if (hi - lo < kWindow) [[likely]] {
                mark(sid);
                ++n_win_;
                lo_ = lo;
                hi_ = hi;



                return;
            }
        } else if (const size_t n = v_.size() - head_; windows_ && n >= kMin && (n & (n - 1)) == 0) {
            if (start_window(sid, n)) return;
        }
        push_array(sid);
    }
    uint64_t front() const {
        if (n_win_ == 0) return v_[head_];
        return head_ != v_.size() && v_[head_] < lo_ ? v_[head_] : lo_;
    }
    void pop_front() {
        if (n_win_ != 0 && (head_ == v_.size() || lo_ < v_[head_])) {
            // The window's lowest entry leaves; the next is the next set bit, at most kWindow
            // bits on. From the second word on the search may have come round the ring: every bit
            // it meets there is of a later entry, the earlier ones of that word having left.
            uint64_t w = lo_ >> 6;
            uint64_t& word = bits_[w & (kWords - 1)];
            word &= ~(uint64_t{1} << (lo_ & 63));
            if (--n_win_ == 0) return;
            uint64_t m = word & (~uint64_t{0} << (lo_ & 63));
            while (!m) m = bits_[++w & (kWords - 1)];
            lo_ = (w << 6) + static_cast<uint64_t>(std::countr_zero(m));
            return;
        }
        if (++head_ == v_.size()) {  // the array is empty: start again at the front
            v_.clear();
            head_ = 0;
        }
    }
    bool empty() const { return n_win_ == 0 && head_ == v_.size(); }
    size_t size() const { return n_win_ + (v_.size() - head_); }
    size_t capacity() const { return v_.capacity(); }

   private:
    static constexpr size_t kWords = kWindow / 64;

    void mark(uint64_t sid) { bits_[(sid >> 6) & (kWords - 1)] |= uint64_t{1} << (sid & 63); }

    // The array's n entries and sid, from the smallest to the largest: if they are close
    // together, all of them move to the window (true). Out of line: it runs once for each time
    // a queue grows long, and inlined into the kernel's event loop it made every run 1 to 2%
    // slower. (The window's push and pop stay inline: as calls they cost the event loop its
    // registers, 3 to 7% on every run with waiting messages; desktop, 2026-10-11.)
    [[gnu::noinline]] bool start_window(uint64_t sid, size_t n) {
        const uint64_t lo = v_[head_] < sid ? v_[head_] : sid, hi = v_.back() > sid ? v_.back() : sid;
        if (hi - lo > kGap * n || hi - lo >= kWindow) return false;
        if (!bits_) [[unlikely]] bits_.reset(new uint64_t[kWords]());  // this recipient's first use of it
        for (size_t i = head_; i < v_.size(); ++i) mark(v_[i]);
        mark(sid);
        v_.clear();
        head_ = 0;
        n_win_ = static_cast<uint32_t>(n + 1);
        lo_ = lo;
        hi_ = hi;



        return true;
    }

    void push_array(uint64_t sid) {



        // Out of room: reclaim the entries already taken if they are at least half of the storage,
        // else let the vector grow.
        if (v_.size() == v_.capacity() && head_ > 0 && head_ >= v_.size() / 2) {
            v_.erase(v_.begin(), v_.begin() + static_cast<std::ptrdiff_t>(head_));
            head_ = 0;
        }
        if (v_.size() == head_ || sid > v_.back()) {  // the usual case for the latest message
            v_.push_back(sid);
            return;
        }
        // The first entry above sid, by a bisection whose steps select rather than jump: where a
        // message lands among those waiting is close to random, and std::upper_bound's
        // mispredicted jumps were 10% of the event loop at 100 quote levels when this array held
        // the whole queue (perf, C4 VM, 2026-10-10). The array is not empty and its last entry
        // is above sid; the last entry of [base, base + len) stays above sid at every step, so
        // at one entry it is the answer.
        const uint64_t* const b = v_.data() + head_;
        size_t base = 0, len = v_.size() - head_;
        while (len > 1) {
            const size_t half = len / 2;
            base += b[base + half - 1] <= sid ? half : 0;
            len -= half;
        }



        v_.insert(v_.begin() + static_cast<std::ptrdiff_t>(head_ + base), sid);
    }

    std::vector<uint64_t> v_;  // [head_, size) ascending
    size_t head_ = 0;
    uint32_t n_win_ = 0;        // entries in the window
    bool windows_ = true;       // the queue may use the window
    uint64_t lo_ = 0, hi_ = 0;  // the smallest and the largest of the window's entries
    std::unique_ptr<uint64_t[]> bits_;  // null, or kWords words: bit (sid & (kWindow - 1)) for a waiting sid
};

static_assert(sizeof(DeferQueue) == 64);  // one cache line a recipient


}  // namespace t3
