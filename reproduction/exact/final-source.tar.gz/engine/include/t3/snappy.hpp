// Minimal Snappy block compressor. Emits a standard snappy stream: varint
// uncompressed-length preamble, then literal/copy elements (4-byte hash
// matching, 64 KiB window, copy2 tags). Any conformant decompressor reads
// it (pyarrow, C++ snappy, python-snappy) — that is the acceptance bar, and
// simulation/tools/ round-trips through pyarrow verify it.
//
// Hand-rolled because the scoring container is offline: vendoring the full
// snappy library (SSE4 dispatch, cmake, tests) for one code path is more
// surface than ~90 lines of format-correct encoder.
#pragma once

#include <cstdint>
#include <cstddef>
#include <string>

namespace snappy {

// Appends the snappy-compressed form of in[0,n) to out.
void compress(const uint8_t* in, size_t n, std::string& out);

// Appends a valid Snappy stream holding in[0,n) as literal elements only (no match search). Our
// pages are already delta/bit-packed, where match search saves ~0-10% at a large CPU cost.
void literal(const uint8_t* in, size_t n, std::string& out);

}  // namespace snappy
